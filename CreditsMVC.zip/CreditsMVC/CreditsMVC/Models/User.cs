﻿using System;
using System.Collections.Generic;

namespace CreditsMVC.Models;

public partial class User
{
    public int UserId { get; set; }

    public string UserName { get; set; } = null!;

    public string Ssn { get; set; } = null!;

    public string FilingStatus { get; set; } = null!;

    public virtual ICollection<Form8801> Form8801s { get; set; } = new List<Form8801>();
}
