﻿using System;
using System.Collections.Generic;

namespace CreditsMVC.Models;

public partial class Form8801
{
    public int FormId { get; set; }

    public int UserId { get; set; }

    public decimal? Line1 { get; set; }

    public decimal? Line2 { get; set; }

    public decimal? Line3 { get; set; }

    public virtual User User { get; set; } = null!;
}
